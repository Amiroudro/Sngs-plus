# Test Report — Engine v2, 2026-11-15 dry-run

**Run:** `python3 run_v2.py --date 2026-11-15 --fresh`, 23:25 Asia/Dhaka, 14 Nov 2026
(dated 15 Nov per instruction; the news window is effectively 13–14 Nov —
see §5). Duration ~4 min. **Nothing published, synced or switched. v1 and
the 08:00 cron untouched.**

## 1. Test suites — all green

| Suite | Result |
|---|---|
| Step 1 (collect) | **43 PASS, 0 FAIL** |
| Step 2 (prefilter) | **11 passed, 0 failed** |
| Step 3 (decide) | **OVERALL: PASS** — 6 script examples + robustness + 11 new 15-Nov decision checks + 30/30 batch invariants |
| Steps 4–6 (facts/check/Bangla) | **74 PASS, 0 FAIL** |
| Steps 7–9 (page/questions/SRS) | **106 PASS, 0 FAIL** (live-fixture count varies with the Bing feed; earlier run 139 — 0 failures either way) |
| Step 10 (vocabulary) | **OVERALL: PASS** — synthetic 20/10/5 exact, every example verbatim, keys match v1 contract; live coverage 52 words / 7 phrases on 14 Nov summaries |

## 2. Dry-run numbers — 14 Nov vs 15 Nov

| Stage | 14 Nov | 15 Nov |
|---|---|---|
| Collected | 107 | **820** (7.7×) |
| Editorial collected | — | 10 |
| Clusters | 106 | 774 |
| Deprioritised (Step 2) | 4 | 51 |
| Step 3: keep / maybe / reject | 35 / 19 / 52 | **85 / 204 / 485** |
| Bodies fetched ok / tried | 28 / 35 | **57 / 85** |
| No-body dropped | 7 | **28** |
| Step 5 dropped / marked যাচাই করুন | 2 / 0 | **4 / 0** |
| Final items | 26 | **53** |
| Editorial slot | — (did not exist) | **FILLED** — "Why falling costs don't always mean cheaper food" (Daily Star, score 2, BD-ECO) |
| Page items / maybe items | 15 / 19 | **15 / 204** |
| Q&A / MCQ / SRS cards | 148 / 46 / 194 | **303 / 111 / 414** |
| Vocabulary | — (did not exist) | **20 words / 10 phrases / 5 revision, no shortfall** (199 words, 27 phrases matched in full bodies) |

Collection by source (15 Nov): Jugantor 415, TBS 257, Prothom Alo English 53,
Prothom Alo Bangla 41, Daily Star 27, Dhaka Tribune 16, Financial Express 5,
MSN 3, others 3. By route: sitemap 660, RSS 89, Bing 47, section pages 14,
editorial 10.

## 3. The six decisions — verified on live data

1. **Direct sources (no Google News).** CLOSED. 820 collected vs 107.
   Jugantor (Bangla daily, news sitemap) alone delivered 415; TBS sitemap
   257. Dead from this VM, all recorded: Dhaka Tribune, New Age, Kaler
   Kantho, Ittefaq (403/404 on every route); Financial Express unusable
   (section links carry no dates); Daily Star flaky (sitemap truncates,
   section pages partial ~half the time).
2. **Editorial slot.** CLOSED. Filled with a real Daily Star opinion piece
   (score 2, BD-ECO); the headline appears nowhere in the 15 news items,
   at-a-glance, top news or maybe list.
3. **BD-EDU topic.** CLOSED as a topic — 4 keeps, including the DU/JU/BUET
   admissions story ("shut doors on HSC supplementary candidates") that
   the 14 Nov rubric rejected. BUT 0 BD-EDU items made the 15-item page:
   all 4 keeps were score 2 and older than the page cutoff (18:06, 14 Nov),
   so they lost fairly on recency. The topic works; the page just had
   newer score-2 competition.
4. **Support-only cap (all topics).** CLOSED in code and synthetic tests
   (flight-delay story → maybe/1). No flight-delay story appeared in the
   15 Nov batch, so no live re-test was possible. The 2 keeps whose
   reason reads "support match" both had a Strong term in another topic
   (a015 diabetes story: "caretaker government"; a036 SAFF final:
   "championship"/"semifinal"), so the cap correctly did not apply.
   Knock-on, see §5: a036's topic label is wrong (INT-REL, should be SPORT).
5. **Ranking (score desc, then newest first).** CLOSED and verified on live
   data. At-a-glance order: 5× score 3 first (published 22:06 → 15:47 →
   12:07 → 11:15 14 Nov → 11:46 13 Nov), then 10× score 2 newest-first
   (00:00 15 Nov → 22:19 → 21:58 → 21:43 → 21:01 → 20:18 → 19:34 →
   19:23 → 18:41 → 18:06, all 14 Nov, Dhaka time — the sort handles mixed
   UTC/+06 formats correctly). Within the BD-ECO section: 3,3,3,3,3,2.
6. **Step 10 vocabulary.** CLOSED. 20/10/5 with no shortfall. Bank:
   281 words + 68 phrases. Traceability spot-checked against the live
   source: the word "state" example is verbatim in the TBS article
   ("State Minister for Land … said he would discuss a proposed
   'One City, Two Town' concept …", verified live 14 Nov 23:31).
   Limits: all 20 words have empty IPA (none appeared in a v1 edition);
   3/10 phrases have only one example sentence; the word list skews
   Basic — ranking by article-count picks the most frequent words
   (state, decision, bank, minister…).

## 4. v1 comparison

**Same-day comparison is not possible yet:** v1 Edition 9 (15 Nov)
publishes at 08:00 via the cron; this dry-run ran 23:25 on 14 Nov.
Compared against the nearest published set, **v1 Edition 8 (14 Nov,
12 stories)**:

- **0 of Edition 8's 12 stories appear on the v2 15 Nov page.**
- Among v2's 85 keeps: 1 exact same story (DU/JU/BUET admissions — from
  13 Nov, too old for the page), 1 same-thread follow-up (case filed
  against Nusrat Tabassum's father; Edition 8 had the fire at her home),
  theme-level overlaps on COP31 (3 v2 page items vs 3 Edition 8 items,
  different stories), diabetes/health, and DU admissions.
- The 14 Nov gap was "0/12 overlap, split downstream"; the 15 Nov
  picture is different: the pool is now 7.7× bigger and the page is
  dominated by fresh TBS sitemap items, while Edition 8's stories are
  yesterday's news. Overlap will only be measurable once a same-day
  v1 edition exists to compare against.

## 5. Which 14 Nov gaps are closed

- Google News breadth → closed (§3.1).
- No editorial slot → closed (§3.2).
- No education topic → closed (§3.3).
- Support-only cap PEOPLE-only → closed (§3.4).
- No importance ranking within score 2 → closed (§3.5).
- No vocabulary module → closed (§3.6).
- US flight-delay rubric miss → closed in code; no live re-test this day.

## 6. Remaining gaps (honest list)

1. **Slug-derived headlines — the biggest quality gap.** 12 of the 15
   page items come from the TBS sitemap, whose plain sitemap carries no
   titles, so headlines are reconstructed from URL slugs: grammar
   stripped, Title-Cased, occasionally truncated mid-word ("Customs Foil
   Attempt Export Ship Propeller Scrap Copper Detect Tk171Cr Revenue E").
   The stories are real; the headlines read like slugs.
2. **Body-fetch misses: 28 of 85 keeps (33%) dropped** for no body text.
   Per-source failure attribution is not recorded — an observability gap.
3. **Topic skew.** SCI took 27 of 85 keeps ("cop" 11× as INT-ORG Strong
   for COP31, "ai" 6×, "এআই" 4×); BD-BANK only 1 keep. The page is
   12/15 from one source (TBS).
4. **Two mislabels.** (a) a036 "India edge Bhutan to reach SAFF
   Championship final" kept as INT-REL — the topic picker prefers the
   country support-match over the SPORT strong hit; should be SPORT
   (script example 6b). (b) a786, a father-and-two-daughters death story
   (Prothom Alo Bangla), kept as SCI score 2 because the summary mentions
   a "টিকা কার্ড" (vaccination card) beside a body — a Strong term in a
   passing mention mislabels the story.
5. **Step 6 Bangla fluency — unchanged, known limit, not fixed in this
   pass.** Fact lines are still telegraphic slot renderings, e.g.
   'findings presented seminar "Peer পর্যালোচনা Forensic Audit Report
   জিডিপি (GDP) (১৪ নভেম্বর ২০২৬)।'
6. **Vocabulary polish.** Empty IPA on all 20 words; 3/10 phrases with a
   single example; Basic-heavy word list (§3.6).
7. **Maybe-items ballooned to 204** (from 19) — the price of 820
   collected. Headline-only, but a very long collapsed list.
8. **Source dead-ends** (from the Decision 1 work): Dhaka Tribune, New
   Age, Kaler Kantho, Ittefaq unreachable; Financial Express dateless;
   Daily Star flaky. TBS sitemap parsing costs ~1m40s per collection.
9. **Run timing.** The dry-run is dated 15 Nov but ran 23:25 on 14 Nov,
   so its news window is 13–14 Nov (only 1 page item is dated 15 Nov).
   A same-day v1 comparison needs Edition 9 (08:00, 15 Nov).

## 7. Files

`runs/2026-11-15/`: articles, clusters, decisions, edition, page,
prefilter-log, prefiltered, questions, sources, srs, vocab JSON files.
Engine code changed in this pass: `step1_collect.py` (v2.1.0, sources),
`step3_decide.py` (BD-EDU, Support-only cap, editorial scoring),
`step7_page.py` (ranking, editorial slot), `run_v2.py` (editorial pick,
Step 10 wiring, collect 4-value unpack fix), `step10_vocab.py` (new),
`rules/RULES.md` + `rules/vocab_bank.json` (new, 281 words / 68 phrases),
`tests/test_step1.py` (43), `tests/test_step3.py` (decision tests),
`tests/test_step789.py` (ranking + editorial tests),
`tests/test_step10.py` (new). `CONTRACTS.md` updated for Decisions 2–6.
`RULES.md` mirrored to `app/assets/engine-rules/rules.md`.
