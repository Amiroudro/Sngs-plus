# Test Report — Sarangsho Plus engine v2, slug-headline fix (2026-11-15)

Date: 2026-11-15 (dry-run, `run_v2.py --date 2026-11-15 --fresh`)
Scope: fix the slug-derived headlines (Rudro's choice, 2026-11-15 01:28).
v1 and the 08:00 cron untouched; nothing published, synced or switched.

## The problem (before)

12 of the 15 page items in the 15 Nov dry-run came from the TBS
sitemap, which carries no titles, so headlines were reconstructed
from URL slugs — grammar stripped, Title-Cased, occasionally
truncated mid-word, e.g. "Customs Foil Attempt Export Ship Propeller
Scrap Copper Detect Tk171Cr Revenue E", "Lack Childcare Keeps 4 10
Urban Women Out Workforce World Bank Study" ("4 10" for "4 in 10"),
"Govt Aims Bring Cancer Treatment Peoples Doorsteps Within 5Yrs
State M…". The stories were real; the headlines read like slugs.

## Investigation (what was checked first)

- **TBS sitemap children are plain urlsets** — no `<news:title>`
  (verified live on sitemap-2026-2.xml, 854,876 bytes).
- **No TBS news sitemap exists**: /news-sitemap.xml, /news_sitemap.xml
  and /sitemaps/news.xml all return 404 (checked 2026-11-15).
- **TBS RSS is stale** (latest 12 Nov 2021) — already dropped.
- **Article pages carry a clean og:title** (verified live on a real
  TBS article: og:title = the exact headline, no suffix; `<title>`
  adds " | The Business Standard"; first `<h1>` matches og:title).
  One page fetch took ~1.9 s.
- **robots.txt allows article URLs** (tbsnews.net: only /includes/,
  /misc/, /modules/, /profiles/, /scripts/, /themes/ and
  /CHANGELOG.txt are disallowed). It asks Crawl-delay: 10 — see
  Remaining gaps; the existing body fetcher does not honour it
  either, so this fix introduces no new behaviour there.

## The fix (chosen: collection-time page-title resolution)

No titled TBS source exists, so the fix fetches the real headline
from the article page — **at collection time, for cluster mains
only, before Step 3 decides**. That ordering is the whole point:
Step 3's evidence_quote must be a verbatim substring of headline +
summary, so the real title has to be in place first; replacing
titles after the decision could break stored quotes.

- `step1_collect.py`: every item now carries `title_source` —
  "feed" (real headline from RSS / news sitemap / Bing / section
  feed), "slug" (derived from the URL slug), "page" (real headline
  fetched from the article page). `extract_page_title(html)` takes
  og:title first (either attribute order), then `<title>`, then the
  first `<h1>`; known site-name suffixes are stripped; a bare-date
  title ("12/11/2026") is rejected and falls through. On any
  failure the slug title stays — never invented, never body text
  as a headline.
- `resolve_slug_titles(articles, clusters)`: fetches pages for
  slug-titled cluster mains only (non-mains never reach Step 3 or
  the page), 4-worker thread pool, 300 s budget, one retry per
  fetch (servers often close mid-read — the same reason
  `fetch_bodies_for_kept` retries). Robots-checked via the existing
  helper; Google News redirects skipped. Also updates the clusters'
  `members_detail` titles. Returns (resolved, failed, seconds);
  counts are in the Step 1 meta and printed by `step1_collect.py`.
- `run_v2.py`: safety net — after the editorial re-pick, any main
  still slug-titled is resolved before Step 3 (normally a no-op;
  collect() already resolved every main).
- `CONTRACTS.md`: `title_source` documented in the Article
  contract. RULES.md untouched (the rubric is unchanged), so no
  mirror was needed.

## Two junk findings fixed along the way (live data)

The first live run exposed non-news URLs in the TBS sitemap that
produced garbage titles either way:

- **32 govt-ad pages** (`/govt-ad/12112026-…`) — og:title is just a
  date ("12/11/2026"); one even became a page main with that as
  its headline. **3 author profile pages** (`/author/…`) — og:title
  is the author's name ("Shahadat Shadhin").
- Fix: `/author/` and `/govt-ad/` added to `SKIP_URL_PARTS`, so
  these are never collected (they are not news; Step 3 would have
  rejected them anyway). Plus the bare-date guard in
  `extract_page_title` as defence in depth.
- A third live finding: one real article kept its slug title on the
  first run because its page fetch failed transiently (the page
  itself is fine — verified live afterwards). Fix: the one retry
  above.

## Test suites — all green

| Suite | Result |
|---|---|
| Step 1 | **61 PASS, 0 FAIL** (incl. 18 new slug-title checks) |
| Step 2 | 11 passed, 0 failed |
| Step 3 | OVERALL: PASS |
| Steps 4–6 | 85 PASS, 0 FAIL (of 85) |
| Steps 7–9 | 180 PASS, 0 FAIL |
| Step 10 | OVERALL: PASS |

New Step 1 checks: title_source markers on all four parsers;
`extract_page_title` (og:title preference, both attribute orders,
`<title>` suffix strip, `<h1>` fallback, empty → "", date-only
og:title rejected with fall-through); `resolve_slug_titles` (main
resolves, members_detail updated, fetch failure keeps slug,
non-main untouched, redirect skipped, one retry rescues a transient
failure, counts); author/govt-ad pages dropped by the sitemap
parser; and a Step 3 check proving a keep's evidence_quote is
still a verbatim substring of headline + summary after title
replacement.

## Fresh dry-run numbers — before / after

| | Before (syllabus dry-run, 15 Nov) | After (this dry-run) |
|---|---|---|
| Collected | 855 | **810** (−35 junk items no longer collected + live-feed drift) |
| Keep / maybe / reject | 85 / 193 / 513 | **87 / 196 / 494** |
| Final items | 57 | **60** |
| Page items | 15 | 15 |
| **Slug headlines on the page** | **12 / 15** | **0 / 15** |
| Slug mains (all clusters) | 241 TBS mains (15 Nov baseline) | **0** (feed 567 + page 224) |
| Slug items remaining | — | 8, all non-mains (never reach the page) |
| Govt-ad / author items | 35 | **0** |
| Q&A / MCQ / analytical | 326 / 114 / 2 | **343 / 118 / 2** |
| facts_en | 15 / 15 | 15 / 15 |
| SRS cards | 440 | 461 |
| Vocab words / phrases / revision | 20 / 10 / 5 | 20 / 10 / 5 (no shortfall) |
| Editorial slot | filled (Daily Star) | filled (same piece) |
| Evidence-quote violations (all 87 kept mains) | — | **0** |
| Dry-run wall time | ~4 min | **5m32s** (title resolution ≈ +1.5 min) |

Page headlines, after (all 15, real headlines now):

- "Customs foil attempt to export ship propeller scrap as copper, detect Tk1.71cr revenue evasion"
- "Govt targets $1.86b in budget support from dev partners in FY27"
- "Lack of childcare keeps 4 in 10 urban women out of workforce: World Bank study"
- "Myanmar airstrike on displaced persons camp kills 12: witnesses"
- "80 cameras installed, AI-powered surveillance planned in Mohammadpur-Adabor"
- "'One City, Two Town': State minister eyes renewable energy, bird sanctuary and recreation…"
- "Govt aims to bring cancer treatment to people's doorsteps within 5yrs: State minister"
- "Measles: Death toll reaches 1,306 as 2 more children die in 24hrs"
- "Packing the Blue Zone: Bangladesh registers record 361 delegates at COP31"
- (plus 6 feed-titled items, incl. the Bangla Prothom Alo headline and the GDP/audit stories)

The old slug artefacts are gone: "4 10" is "4 in 10", "Tk171Cr" is
"Tk1.71cr", nothing is truncated mid-word.

## Files changed

- `step1_collect.py` — `title_source` on all four parsers;
  `extract_page_title`, `_strip_site_suffix`, `_is_bare_date`,
  `_resolve_one_title`, `resolve_slug_titles`; hook into
  `collect()` + meta; `SKIP_URL_PARTS` += `/author/`, `/govt-ad/`.
- `run_v2.py` — title safety net after the editorial re-pick.
- `CONTRACTS.md` — `title_source` in the Article contract.
- `tests/test_step1.py` — 18 new checks (section 5).

## Remaining gaps (honest)

1. **8 slug-titled items remain, all cluster non-mains.** They never
   reach Step 3 or the page, so nothing the reader sees is a slug —
   but if a future re-pick ever promoted one without the safety net
   firing, it would show a slug. The run_v2 safety net covers the
   known re-pick path.
2. **TBS robots.txt asks Crawl-delay: 10**, which the engine does
   not honour (4 parallel fetchers, no delay) — the same is true of
   the existing body fetching, so this fix changes nothing there,
   but a strict reading of the file would want a delay the pipeline
   cannot afford at 200+ fetches.
3. **Titles are resolved for mains only.** Clustering/dedup still
   compares slug titles for members; a member's slug title is what
   Step 2 sees. No mis-clustering was observed, but the dedup text
   for slug members is still word-soup.
4. **Step 6 Bangla is still telegraphic** (pre-existing, untouched).
5. **SCI skew persists** in the keep pool (same as before).
6. The dry-run overwrote `runs/2026-11-15/` outputs with the new
   edition (expected for a fresh run); the earlier 15 Nov reports
   (`TEST_REPORT_2026-11-15.md`, `TEST_REPORT_2026-11-15-syllabus.md`)
   are intact alongside this one.

## Addendum — 2026-11-15 01:53, CAT independent re-verification

CAT re-ran every suite itself and re-checked the dry-run files.
**All green, confirmed:** Step 1 61/61, Step 2 11/11, Step 3 PASS,
Steps 4–6 85/85, Steps 7–9 181/181 (one more than the 180 above —
live-fixture count varies run to run), Step 10 PASS. Title provenance
recounted from the articles file: feed 578, page 224, slug 8 (810
total; the "feed 567" in the table above is a stale count — the
correct figure is 578). **Slug mains: 0 of 791, verified** (CAT's
first count script errored on the clusters file shape — a dict with
a `clusters` key, not a list — and was re-run correctly). Slug items
total 8, all non-mains. The 15 page headlines were read directly
from the page file: all real headlines, no slugs.
