# Test Report — Sarangsho Plus engine v2, syllabus proposals (2026-11-15)

Date: 2026-11-15 (dry-run, `run_v2.py --date 2026-11-15 --fresh`)
Scope: implementation of all 10 syllabus-analysis proposals
(`~/workspace/sarangsho-plus/syllabus-analysis-2026-11-14.md` §5,
approved by Rudro 2026-11-15 00:01). v1 and the 08:00 cron untouched;
nothing published, synced or switched.

## Test suites — all green

| Suite | Result |
|---|---|
| Step 1 | 43 PASS, 0 FAIL |
| Step 2 | 11 passed, 0 failed |
| Step 3 | OVERALL: PASS (incl. 16 new syllabus checks; batch invariants 30/30) |
| Steps 4–6 | 83 PASS, 0 FAIL (incl. 9 new `facts_en` checks) |
| Steps 7–9 | 166 PASS, 0 FAIL (incl. 29 syllabus checks: P7 18, P8 2, P9 9; + 5 `_pub_date` checks) |
| Step 10 | OVERALL: PASS |

Note: the Step 7–9 total varies slightly between runs (159–175) because
part of that suite checks live-RSS fixtures; the syllabus section is
fixed fixtures and deterministic — all 34 new checks pass every run.

## Dry-run numbers (final run, 4th of the day)

| | Baseline 15 Nov (pre-syllabus, `TEST_REPORT_2026-11-15.md`) | Final (post-syllabus) |
|---|---|---|
| Collected | 820 | 855 |
| Keep / maybe / reject | 85 / 204 / 485 | 85 / 193 / 513 |
| Bodies fetched | 58 ok | 61 / 85 tried |
| No-body dropped | 28 | 24 |
| Step 5 dropped | 4 | 4 |
| Final items | 53 | 57 |
| Page items | 15 | 15 |
| Editorial slot | filled (Daily Star) | filled (same piece) |
| Q&A / MCQ | 303 / 111 | 326 / 114 |
| Analytical (new) | — | 2 (cap) |
| `facts_en` items (new) | — | 15 / 15 |
| SRS cards | 414 | 440 |
| Vocab words / phrases / revision | 20 / 10 / 5 | 20 / 10 / 5 (no shortfall) |

Collected counts differ run to run because each run re-fetches live
feeds (820 → 849 → 847 → 855 across the day's four runs); the keep
count is stable at 85. The proposals did not blow up the pipeline.

## Per-proposal verification

### P1 — first / record / ranking with number + date scores 3
- Code + RULES.md: score-3 list includes "a first / record / ranking
  with a number and a date" (ranking only when Bangladesh's position
  is stated — see P2).
- Synthetic tests (16 checks, Step 3): remittance record keep/3,
  first-ever satellite keep/3, first without number/date keep/2,
  "first phase" keep/2 not 3. All pass.
- **Live data: NOT exercised on 15 Nov** — no first/record story with
  number+date appeared in the batch. Watch the next dry-run.

### P2 — ranking/index upgrade: keep/2 when Bangladesh's position stated
- Code + RULES.md: ranking path — BD position → keep/2 (keep/3 with
  number+date); no BD position → maybe/1. Awards keep the old
  BD-involvement rule. Strong-substance guard: a story with a Strong
  topic hit AND a number is decided on its own merits, not demoted
  by the awards rule.
- Synthetic tests: ranking with BD position keep/2, +number/date
  keep/3, no BD position maybe/1, award with BD person keep/2.
- Live data: 5 ranking/award maybes. a332 is a ranking with no
  Bangladesh position → maybe/1 with the new reason
  ("ranking/index with no Bangladesh position") — the new rule firing
  correctly. The other 4 are awards with no BD involvement (correctly
  maybe under the old award rule). **No ranking WITH a BD position
  appeared live** — the upgrade path is synthetic-only so far.

### P3 — BD-NATL Strong += gender terms
- Added: gender equality, নারী অধিকার, women empowerment,
  নারীর ক্ষমতায়ন, gender gap, লিঙ্গ বৈষম্য (kept existing
  "women's development").
- Synthetic: women empowerment + gender gap keep/BD-NATL. Pass.
- Live data: no gender story in the batch — synthetic-only.

### P4 — ENV Strong += climate terms
- Added: climate diplomacy, জলবায়ু কূটনীতি, loss and damage,
  ক্ষতিপূরণ, climate finance, জলবায়ু অর্থায়ন, climate adaptation,
  জলবায়ু অভিযোজন, cop29, cop30, cop31.
- Synthetic: climate finance + loss and damage keep/ENV. Pass.
- **Live data: VERIFIED.** a219, a233 keep/2 ENV on "climate
  finance"; a233 also matches "cop31".

### P5 — BD-GOV Strong += election-law terms
- Added: representation of the people order, rpo, election
  observation, নির্বাচন পর্যবেক্ষণ, electoral law, নির্বাচনী আইন.
- Synthetic: RPO keep/BD-GOV. Pass.
- Live data: no RPO/election-observation story in the batch —
  synthetic-only.

### P6 — BD-ECO Strong += plan terms
- Added: vision 2041, ভিশন ২০৪১, delta plan, ডেল্টা প্ল্যান, smart
  bangladesh, স্মার্ট বাংলাদেশ, five year plan, পঞ্চবার্ষিক পরিকল্পনা,
  adp implementation, এডিপি বাস্তবায়ন.
- Synthetic: Vision 2041/Delta Plan + Smart Bangladesh keep/BD-ECO.
  Pass.
- Live data: no plan story in the batch — synthetic-only.

### P7 — `focus_paragraph` for score-3 items only
- 3–4 sentences, প্রসঙ্গ → তথ্য → বিশ্লেষণ → উপসংহার, built only
  from the verified fact list + [পটভূমি]; omitted when the fact list
  cannot support 3 sentences.
- Live data: all 5 score-3 page items carry a 4-sentence paragraph;
  all 10 score-2 items correctly have none.
- Verified against re-fetched bodies: **every non-date number in all
  5 paragraphs appears in its article (0 missing)**.
- **Bug found by live verification and fixed:** slug-derived TBS
  headlines express figures in a different unit than the body
  ("Tk159 Crore" vs "1.59 billion"), so the headline number failed
  the Step 5 check in 3 of 4 paragraphs in the first run.
  Fix (`step7_page.py`): headline numbers not present in the article
  body are dropped from the paragraph (headline words stay), and a
  unit suffix glued to a dropped number ("171Cr", "186B") goes with
  it — so the paragraph never reads "TkCr" or "Targets B Budget".
  When no body is available, the allowed numbers fall back to the
  fact lines + date. 9 new tests cover this (drop/keep/fallback/
  suffix). Final live paragraphs read e.g. "Govt Targets Budget
  Support Dev Partners Fy27 (2026-11-14)" (186B dropped, Fy27 kept)
  and "Customs Detects Tk Crore Revenue Irregularities…" (159 dropped).
- **Second bug found by live verification and fixed:** the item date
  was built by slicing the first 10 chars of the published string
  (`run_v2.py`), which is only correct for ISO dates — a Financial
  Express RFC-2822 date ("Sat, 14 Nov 2026 02:00:00 GMT") came out
  as "Sat, 14 No" and leaked into page dates and focus paragraphs.
  Fix: new `run_v2._pub_date()` parses any pub-date format to
  YYYY-MM-DD via `common.parse_pubdate` (5 tests). Final live
  paragraphs show clean "(2026-11-14)" dates.

### P8 — `facts_en` first-class for every story
- Every page item carries `facts_en`; English articles keep the same
  facts, Bangla articles get a glossary rendering (same values,
  digits normalised, units mapped, "উল্লেখ নেই" → "not stated").
- Live data: **15/15 page items carry `facts_en` (3–5 facts each)**.
  Verified against re-fetched bodies with Step 5 rules (quotes
  verbatim, numbers trace, names trace — including glossary-translated
  names checked against their Bangla originals): **0 issues across
  all 15 items**, including both Prothom Alo Bangla items.
- Known limit (unchanged): Bangla renderings are glossary-based,
  not fluent translation (e.g. "Bangladesh Bank interest rate
  কমিয়েছে").

### P9 — `analytical` question type, max 2 per edition, score-3 only
- Stems are implication/solution ("এই সিদ্ধান্তের বাংলাদেশের জন্য
  প্রভাব কী?", "এই পূর্বাভাস অনুযায়ী বাংলাদেশের জন্য কী করা উচিত?");
  answers grounded only in verified facts + [পটভূমি], marked
  "বিশ্লেষণ (তথ্যের ভিত্তিতে, নতুন তথ্য নয়)"; kind "analytical",
  not fed to SRS.
- Live data: **2 analytical questions (the cap), both from score-3
  items** (a045 forecast stem, a024 implication stem). Verified
  against re-fetched bodies: every number in both answers appears
  in the article; both source quotes are verbatim.

### P10 — BD-EDU stays out (hold the line)
- **Confirmed: topic list is still 10.** `grep -c BD-EDU rules/RULES.md`
  = 0. Final dry-run topic distribution: SCI 28, INT-ORG 16, BD-ECO 9,
  PEOPLE 9, ENV 8, BD-GOV 7, INT-REL 5, SPORT 2, BD-BANK 1, BD-NATL 0
  (no BD-NATL keep today). No education topic anywhere.

## Files changed

- `rules/RULES.md` (mirrored to `app/assets/engine-rules/rules.md`;
  diff verified identical) — P1–P7 rule text.
- `CONTRACTS.md` — Step 3 notes (P1/P2), Step 4 `facts_en` (P8),
  Step 7 item shape + focus-paragraph rule (P7), Step 8 analytical
  type (P9).
- `step3_decide.py` — P1/P2 (first/record/ranking signals, BD-position
  check, strong-substance guard).
- `step4_facts.py` — P8 (`render_facts_en`, glossary, unit map).
- `step7_page.py` — P7 (`build_focus_paragraph`, headline-number
  sanitising, `body_numbers` passthrough) + P8 passthrough.
- `step8_questions.py` — P9 (`analytical_question_for_item`,
  `analytical_for_items`, cap 2).
- `run_v2.py` — P8/P9 wiring (`facts_en` on final items,
  `analytical` in questions + edition JSON) + `_pub_date` fix.
- `tests/test_step3.py`, `tests/test_step456.py`,
  `tests/test_step789.py` — new per-proposal tests (16 + 9 + 34).

## Remaining gaps (honest)

1. P1, P2-upgrade, P3, P5, P6 had no live story on 15 Nov — verified
   synthetically only. Watch the next dry-run for a first/record with
   number+date, a ranking WITH a Bangladesh position, and gender /
   RPO / Vision-2041 stories.
2. Slug-derived TBS headlines still read like slugs ("Customs Detects
   Tk Crore Revenue Irregularities Export Consignments Two Garment");
   the numbers are now traceable, but the headline words themselves
   are fragments. Step 6 Bangla is still telegraphic (pre-existing).
3. SCI skew persists: 28 of 85 keeps are SCI (mostly space/science
   wires); BD-NATL had 0 keeps today.
4. 24 of 85 kept items dropped for no body (same as before); the
   maybe-list is still large (193).
5. Edge case (out of scope, noted): a Gaibandha building winning a
   world architecture award stays maybe — the BD-marker list has no
   district names, so "গাইবান্ধা" alone does not count as a Bangladesh
   marker.
6. v1 longest-option-correct and other v1 issues untouched — v1 frozen
   by design; the live switch remains Rudro's call.

## Addendum — 2026-11-15 00:42, CAT re-verification (after delivery)

CAT re-ran the suites independently before reporting. Step 3 passed,
but **Steps 4–6 came back 81 PASS, 2 FAIL (of 83)** — not the 83/83
in the table above. Root cause, one live article (TBS, "Bangladesh
seeks new debt strategy"): the sentence "total outstanding debt stood
at Tk22,06,462 crore" — Step 4's `NUM_RE` only allowed 3-digit comma
groups, so it matched "22" and left ",06,462" in the fact text; Step 5
rightly rejected it ("number 06462 not in article") and dropped the
fact, keeping 4. **Step 5 worked as designed; the extractor was wrong
for Indian grouping**, which Bangladeshi news uses constantly
(22,06,462 / 9,59,311). This is a pre-existing extractor weakness,
not a syllabus-proposal regression (the syllabus pass never touched
`NUM_RE`; the live-article test is non-deterministic and the earlier
run simply fetched different articles).

**Fix applied by CAT:** `step4_facts.py` `NUM_RE` Western branch
`(?:,[0-9]{3})*` → `(?:,[0-9]{2,3})*`, so comma groups of 2 or 3
digits tokenise as one number — matching Step 5, which strips commas
before checking. Regression test added (`test_indian_grouping`, 2
checks, fixed fixture). **Re-run after the fix: Steps 4–6 85/85, and
all other suites green** — Step 1 43/43, Step 2 11/11, Step 3 PASS,
Steps 7–9 166/166, Step 10 PASS. v1 untouched throughout. The dry-run
numbers above stand (Step 5 had already dropped any mis-split facts,
so the published data was never wrong).
