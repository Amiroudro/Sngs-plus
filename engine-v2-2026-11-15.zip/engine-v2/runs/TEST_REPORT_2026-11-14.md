# Sarangsho Plus engine v2 — test report (dry run, 2026-11-14)

Date: 2026-11-14 (runs re-executed 16:47 Asia/Dhaka, after a test-suite
re-run clobbered the first dry-run inputs; the numbers below are from the
final self-consistent run). Nothing published, synced or switched. v1 frozen
and untouched.

## 1. What was built (per step)

| Step | Files | Status |
|---|---|---|
| Shared groundwork | `rules/RULES.md` (23,601 B; mirrored to `app/assets/engine-rules/rules.md`, engine copy canonical), `rules_loader.py`, `CONTRACTS.md`, `common.py` | DONE |
| 1 Collect | `step1_collect.py`, `tests/test_step1.py` | DONE — 21/21 PASS |
| 2 Pre-filter | `step2_prefilter.py`, `tests/test_step2.py` | DONE — 11/11 PASS |
| 3 Decide | `step3_decide.py`, `tests/test_step3.py` | DONE — 6/6 script examples + 30/30 batch invariants, OVERALL PASS |
| 4 Facts | `step4_facts.py` | DONE (with 5–6, 74/74) |
| 5 Check | `step5_check.py` | DONE — broken-fact proofs all caught |
| 6 Bangla style | `step6_style.py` | DONE — slot format (see §5) |
| 7 Daily page | `step7_page.py` | DONE (with 8–9, 113/113) |
| 8 Questions | `step8_questions.py` | DONE |
| 9 Study (SRS) | `step9_study.py` | DONE — intervals 1→3→7→14 verified |
| Orchestrator | `run_v2.py` (Steps 1→9, cluster mains only to Step 3, bodies only for kept items) | DONE |

All step tests re-run after the dry-run fixes below: **21 + 11 + PASS + 74 + 113, zero failures.**

## 2. Dry-run numbers (2026-11-14, final run)

- Collected: **107 articles in 106 clusters** (Bing + Prothom Alo; Google News RSS all 9 queries dead — robots.txt, see §6)
- Pre-filter: 4 deprioritised (logged, none deleted)
- Decide (mains only): **keep 35, maybe 19, reject 52**
- Bodies fetched for kept: **28/35** (7 no-body: 5 Dhaka Tribune 403, 2 MSN JS pages)
- Step 5: 2 dropped (<2 facts), 0 marked যাচাই করুন → **26 final items**
- Page: **15 full items** (cap), **19 maybe items**, Top News 10 lines, changes 4, GK footer present
- Questions: **148 Q&A, 46 MCQ** (all recall kind; every MCQ quote verified verbatim by Step 5)
- SRS: **194 cards**, next_review = tomorrow, interval 1

Sections on the page: অর্থনীতি ও ব্যাংকিং 10, বাংলাদেশ (রাজনীতি, আইন, প্রশাসন) 2,
বিজ্ঞান, প্রযুক্তি ও পরিবেশ 2, আন্তর্জাতিক 1. Topics: BD-ECO 6, BD-BANK 4,
BD-NATL 1, BD-GOV 1, INT-REL 1, ENV 1, SCI 1. No score-3 items this day.

Run outputs: `engine-v2/runs/2026-11-14/` — `articles-`, `clusters-`,
`prefiltered-`, `prefilter-log-`, `decisions-`, `page-`, `questions-`,
`srs-`, `edition-2026-11-14.json`.

## 3. v1 comparison (same day, Edition 8, 2026-11-14)

| | v1 Edition 8 | v2 dry run |
|---|---|---|
| Stories / page items | 12 | 15 (26 checked, cap 15) |
| Words / phrases / revision | 20 / 10 / 5 | — (no vocab module in v2, see §6) |
| MCQs | 25 | 46 (Q&A 148 extra) |
| Sources | 16 | Bing + Prothom Alo only |
| Editorial/opinion stories | 3 | 0 |
| Coverage line | stale "7 Nov 2026" start (known v1 issue) | no coverage field in page contract |

**Headline overlap on the page: 0 of v1's 12.** That looks alarming until you
check the collection level: **all 12 v1 stories WERE collected by v2.** The
divergence is downstream:

- **7 rejected by the rubric (score 0)** — by design of the script's rules:
  - 3 opinion/columns (Kalabogi→COP31, healthcare decentralisation, energy/gas
    rationing): v2 has no editorial/opinion path; the rubric scores news
    events, and columns carry none. v1 carried 3 editorial/opinion stories.
  - 2 statements with no decision/action ("India declines comment on Hasina's
    return", "Bangladesh presses for affordable climate finance"): the script's
    "minister statement → reject 0" example covers these.
  - DU/JU/BUET shut doors on HSC supplementary candidates: **no education /
    admissions topic in the 10-topic list** — no Strong term matched. Genuine
    rubric gap (admissions news is exam-relevant for this audience).
  - "Jail terms, fines proposed for harassing animals" and "Tourists flock to
    Cheradia": niche proposal / tourism — no Strong term; defensible rejects.
- **2 kept but cut by the 15-item cap** (Nusrat home fire / parliament row,
  COP31 climate-justice op-ed). The page fills **first-15-in-collection-order**,
  with no importance ranking within score 2. 11 checked items in total were
  cut. (Note: the COP31 $10bn finance story was kept in the first dry-run
  batch but had aged out of Bing's fresh results by the final re-run's
  collection — live feeds shift within the hour, so same-day re-runs are not
  identical.)
- **1 kept and on the page from the same news cycle** (Nusrat's father case
  filed) — v2 covers the cycle, just not v1's exact story pick.

**One rubric miss on the page:** "US flight delays and cancellations continue
as FAA services resume" kept as INT-REL on a **Support-only** match ("united
states"), no Bangladesh angle — violates the style guide's "international only
with a Bangladesh angle". The Support-only cap (maybe/1) was applied to PEOPLE
only during Step 3 testing; it needs to apply to all topics (or INT stories
need a Bangladesh-angle requirement).

## 4. Fixes made during the dry run (all re-tested, suites still green)

1. **Body cleaner** (`common.clean_body_text`, new; `fetch_bodies_for_kept`
   uses it): paragraph-aware, drops bylines/captions/newsletter CTAs/related
   blocks, anchors at the article title, JSON-LD `articleBody` fallback for
   JS pages. Two bugs found live and fixed: (a) a `<header>` strip ate TBS
   article bodies (unclosed site header + article `<header>`); (b) a
   "Related News" cut fired on a sidebar that precedes the body in TBS's DOM
   — now the cut only fires after the first real paragraph, and a pre-body
   related block is skipped line-by-line.
2. **Partial-read rescue** (`common.fetch`): Daily Star closes connections
   mid-read — `IncompleteRead.partial` (up to 73 KB) is now used; rescued 1 of
   2 DS bodies. One retry added.
3. **Status tightening** (`step4_facts`): bare "will"/"shall"/"to be"/"ঘোষণা"
   no longer mean "scheduled" (they mislabelled quoted speech, e.g. the Nusrat
   case); "planned"→proposed, "might"→forecast.
4. **Number furniture** (`_number_matches` + `_make_what`): times ("07:50 pm")
   and "2 min read" are no longer picked as fact values or left in "what".
5. **Byline fragments** (`_core_sentence` + `_is_chrome`): "Published: 13"
   no longer becomes a fact with value 13; "min read" and "8000 char.)"
   sentences are chrome.
6. **Line-boundary sentences** (`clean_body_text` keeps `\n`;
   `split_sentences` splits on newlines): a related-headline line no longer
   glues onto the next article sentence and pollutes its fact/MCQ (the
   "Bata India … Bangladesh Bank doubles … 120 USD" stem is gone).

Verified clean after the fixes: 0 occurrences of `char.)`, `min read`,
`Keep updated`, `File photo`, `Last modified`, `Illustration:`,
`Published:`, `Bata India`, `TBS Report` in the page + questions.

## 5. Known quality limits (honest, not fixed)

- **Step 6 lines are telegraphic slot renderings, not fluent Bangla**
  ("বাংলাদেশ ব্যাংক doubles concessional ঋণ scheme mn: ১২০ মার্কিন ডলার।").
  Readable, numbers exact, but not prose. Some "what" fragments are still
  garbled ("Against backdrop, morning September last বছর, Abdul Halim his: ১৩।").
- **Headlines stay in the article's language** (English for English papers).
  No Bangla headline rendering in v2; the app would show English headlines
  above Bangla fact lines.
- **Maybe-items path and ranking-triple rendering unexercised on live data:**
  no maybe item reached the page this run, and no ranking triple fired
  (all `triple: None`).
- **Body-fetch misses (7/35 kept):** Dhaka Tribune 403 from this VM (5),
  MSN JS-rendered pages (2; JSON-LD fallback found no `articleBody`),
  Daily Star IncompleteRead (1 unrescued — 0 bytes).
- **Step 5(b)** does not number-check the fact's `date` field; a month+year-only
  mention is not an absolute date (carried from Step 4–6 testing).

## 6. Open decisions for Rudro (do not decide alone)

1. **Google News RSS + robots.txt:** strict compliance costs most of v1's
   discovery breadth (v1 got ~300 items/run via Google News; v2 got 107 via
   Bing + Prothom Alo). All 12 v1 stories were still found this day, but that
   is one day's evidence.
2. **Editorial/opinion slot:** v2 has none. v1 carried 3/12. Add an editorial
   route + slot to the rubric, or accept the narrower page?
3. **Education/admissions topic:** add one (HSC/university admissions are
   exam-relevant), or leave the 10-topic list as specified?
4. **Support-only cap:** extend the maybe/1 cap from PEOPLE to all topics
   (fixes the US flight-delay keep)?
5. **Page ranking:** order the 15 by something better than collection order
   (score, then topic balance/recency)?
6. **Vocabulary module:** v2 has no words/phrases/revision lists. If v2 ever
   replaces v1, that is a Step 10 — the app currently shows 20 words +
   10 phrases + 5 revision per edition.
7. **v2 → live switch:** only on Rudro's word. v1 and the 08:00 cron untouched.

## 7. Files changed in this pass

- `engine-v2/common.py` — `clean_body_text()`, `IncompleteRead` partial rescue
- `engine-v2/step1_collect.py` — uses `clean_body_text`, one fetch retry
- `engine-v2/step4_facts.py` — chrome/status/number/published-core/newline
  sentence fixes
- `engine-v2/run_v2.py` — orchestrator (new)
- `engine-v2/runs/2026-11-14/` — dry-run outputs (see §2)
- `engine-v2/runs/TEST_REPORT_2026-11-14.md` — this file
