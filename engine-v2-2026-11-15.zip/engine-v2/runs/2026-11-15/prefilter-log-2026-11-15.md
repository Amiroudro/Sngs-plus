# Pre-filter log — 2026-11-15

Deprioritised headlines: 54 (low priority only; nothing was deleted, Step 3 still decides each one).

- [a016] Eva Arman returns, dedicates new song ‘Probashi’ to expatriates — The Daily Star (matched: singer)
  https://www.thedailystar.net/culture/music/news/eva-arman-returns-dedicates-new-song-probashi-expatriates-4324426
- [a028] Four AL men arrested in Dhaka's Azimpur — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/four-al-men-arrested-dhakas-azimpur-1602921
- [a063] Police super arrested in Chattogram sedition case over alleged links to Awami League — Prothom Alo English (matched: arrested)
  https://en.prothomalo.com/bangladesh/local-news/7e3ik51at7
- [a066] 294 murders a month on average as 2,938 murder cases filed in 10 months — Prothom Alo English (matched: murder)
  https://en.prothomalo.com/bangladesh/crime-and-law/qegp0kut41
- [a073] Young man dies in fire at Korail slum — Prothom Alo English (matched: fire)
  https://en.prothomalo.com/bangladesh/5lgkzau7r4
- [a100] No possibility of fire at Nusrat’s house from short circuit: Rural electricity official — Prothom Alo English (matched: fire)
  https://en.prothomalo.com/bangladesh/local-news/yh64q83nl9
- [a143] Four-member probe committee formed over fire at MP Nusrat's Kushtia home — The Business Standard (matched: fire)
  https://www.tbsnews.net/bangladesh/crime/four-member-probe-committee-formed-over-fire-mp-nusrats-kushtia-home-1601581
- [a158] Man arrested with over 3kg of illegal gold in Ctg — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/crime/man-arrested-over-3kg-illegal-gold-ctg-1601671
- [a175] Train services resume after fire breaks out in Egarosindur Godhuli Express engine — The Business Standard (matched: fire)
  https://www.tbsnews.net/bangladesh/train-services-resume-after-fire-breaks-out-egarosindur-godhuli-express-engine-1601756
- [a194] RMG workers’ groups demand release of arrested activists, withdrawal of cases — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/rmg-workers-groups-demand-release-arrested-activists-withdrawal-cases-1601871
- [a206] 19-year-old worker mauled to death by tiger during TikTok shoot in Pakistan, influencer arrested — The Business Standard (matched: arrested)
  https://www.tbsnews.net/world/south-asia/19-year-old-worker-mauled-death-tiger-during-tiktok-shoot-pakistan-influencer
- [a217] 1 arrested after man beaten to death on bicycle theft suspicion in Ctg — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/1-arrested-after-man-beaten-death-bicycle-theft-suspicion-ctg-1601991
- [a232] Bapex starts operations to extinguish Inani gas well fire after 19 days — The Business Standard (matched: fire)
  https://www.tbsnews.net/bangladesh/bapex-starts-operations-extinguish-inani-gas-well-fire-after-19-days-1602081
- [a254] Rehabilitation can restore work capacity of stroke, accident survivors: Experts — The Business Standard (matched: accident)
  https://www.tbsnews.net/bangladesh/health/rehabilitation-can-restore-work-capacity-stroke-accident-survivors-experts-1602216
- [a280] Rehabilitation Can Help Stroke Accident Survivors Regain Work Capacity Experts — The Business Standard (matched: accident)
  https://www.tbsnews.net/bangladesh/health/rehabilitation-can-help-stroke-accident-survivors-regain-work-capacity-experts
- [a293] Lawyer, former Chhatra League member sent to jail in attempted murder case — The Business Standard (matched: murder)
  https://www.tbsnews.net/bangladesh/court/lawyer-former-chhatra-league-member-sent-jail-attempted-murder-case-1602446
- [a303] 17 banned Awami League men arrested over crude bomb blasts at Jashore court premises — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/crime/17-banned-awami-league-men-arrested-over-crude-bomb-blasts-jashore-court-premises
- [a310] Ctg Range Reserve Force SP arrested in sedition case over alleged links with AL leaders — The Business Standard (matched: arrested)
  https://www.tbsnews.net/bangladesh/crime/ctg-range-reserve-force-sp-arrested-sedition-case-over-alleged-links-al-leaders
- [a316] 19-year-old killed as fire guts homes, shop in Korail slum — The Business Standard (matched: fire)
  https://www.tbsnews.net/bangladesh/19-year-old-killed-fire-guts-homes-shop-korail-slum-1602761
- [a325] Iran's navy says three tankers on fire after hitting mines in Hormuz — The Business Standard (matched: fire)
  https://www.tbsnews.net/worldbiz/middle-east/irans-navy-says-three-tankers-fire-after-hitting-mines-hormuz-1602816
- [a407] চাকরির প্রলোভনে কিশোরীকে আটকে ধর্ষণ, অভিযুক্ত গ্রেফতার — Jugantor (matched: ধর্ষণ)
  https://www.jugantor.com/country-news/1184637
- [a445] যুবককে হত্যার ৩০ মিনিট পর নিজেই ধরা দিলেন খুনি — Jugantor (matched: হত্যা)
  https://www.jugantor.com/country-news/1184589
- [a461] ভোরে কড়াইল বস্তিতে আগুন, ঘুমন্ত তরুণের মৃত্যু — Jugantor (matched: আগুন)
  https://www.jugantor.com/capital/1184566
- [a464] কড়াইল বস্তিতে আগুনে তরুণের মৃত্যু — Jugantor (matched: আগুন)
  https://www.jugantor.com/capital/1184563
- [a475] পরিবারের ৭ সদস্যকে হত্যার পর বললেন, ‘এখন শান্তিতে আছি’ — Jugantor (matched: হত্যা)
  https://www.jugantor.com/international/1184550
- [a511] রাজধানীতে বহুতল ভবনে আগুন — Jugantor (matched: আগুন)
  https://www.jugantor.com/capital/1184340
- [a522] বগুড়ায় চার বছরের শিশুকে ধর্ষণের অভিযোগ — Jugantor (matched: ধর্ষণ)
  https://www.jugantor.com/country-news/1184288
- [a531] ৯ বছরের শিশু শিক্ষার্থীকে ধর্ষণের অভিযোগ, শিক্ষককে পিটুনি — Jugantor (matched: ধর্ষণ)
  https://www.jugantor.com/country-news/1184278
- [a536] গার্মেন্টসে চাকরির প্রলোভনে ১৫ বছরের কিশোরীকে ধর্ষণের অভিযোগ — Jugantor (matched: ধর্ষণ)
  https://www.jugantor.com/country-news/1184270
- [a555] নারায়ণগঞ্জে আনসারের নিরাপত্তায় সচল শিল্পাঞ্চল ও মহাসড়ক; দুর্ঘটনায় আহতকে উদ্ধার — Jugantor (matched: দুর্ঘটনা)
  https://www.jugantor.com/country-news/1184249
- [a644] ভারতীয় গ্যাংস্টার লরেন্স বিষ্ণোই পরিচয়ে মাহমুদা মিতুকে হত্যার হুমকি — Jugantor (matched: হত্যা)
  https://www.jugantor.com/politics/1184147
- [a673] আগুন শর্টসার্কিট থেকে নয়, অথচ স্বরাষ্ট্রমন্ত্রী হামলাকারীদের দায়মুক্তি দিয়েছেন: আসিফ মাহমুদ — Jugantor (matched: আগুন)
  https://www.jugantor.com/politics/1184112
- [a689] শিশুদের ফুটবল খেলাকে কেন্দ্র করে বৃদ্ধকে পিটিয়ে হত্যা — Jugantor (matched: হত্যা)
  https://www.jugantor.com/country-news/1184093
- [a693] ট্রাক-মোটরসাইকেলের মুখোমুখি সংঘর্ষে ইএসডিও কর্মকর্তা নিহত — Jugantor (matched: সংঘর্ষ)
  https://www.jugantor.com/country-news/1184089
- [a713] হরমুজে মাইনে আঘাত, দুই তেলবাহী জাহাজে আগুন — Jugantor (matched: আগুন)
  https://www.jugantor.com/international/1184062
- [a721] গিনিতে স্বর্ণের খনি বন্ধের প্রতিবাদে সংঘর্ষ,  নিহত ১০ — Jugantor (matched: সংঘর্ষ)
  https://www.jugantor.com/international/1184023
- [a732] আগুনে পুড়ল রকটের বুস্টার, ‘ডাবল ক্যাচ’ পরীক্ষায় ধাক্কা স্পেসএক্সের — Jugantor (matched: আগুন)
  https://www.jugantor.com/international/1184008
- [a754] জুরাইনে স্যানিটারি মিস্ত্রিকে কুপিয়ে হত্যা — Jugantor (matched: হত্যা)
  https://www.jugantor.com/capital/1183896
- [a762] জামায়াত কার্যালয়ে আগুন দেওয়ার অভিযোগ, জড়িতদের গ্রেফতারে আলটিমেটাম — Jugantor (matched: আগুন)
  https://www.jugantor.com/country-news/1183827
- [a773] টুঙ্গিপাড়ায় পুলিশের গাড়িতে আগুন, ২২২৪ জনের বিরুদ্ধে মামলা, গ্রেফতার ৪ — Jugantor (matched: আগুন)
  https://www.jugantor.com/country-news/1183816
- [a786] গণহত্যার দায়ে শেখ হাসিনাকে বিচারের মুখোমুখি করতে হবে: রিজভী — Jugantor (matched: হত্যা)
  https://www.jugantor.com/politics/1183801
- [a790] এমপির সংবর্ধনা অনুষ্ঠানে সংঘর্ষ, দলীয় পদ হারালেন দুই ভাই — Jugantor (matched: সংঘর্ষ)
  https://www.jugantor.com/country-news/1183797
- [a802] নুসরাতের বাড়িতে আগুনের ঘটনায় সরকারের ব্যর্থতা দেখছেন বিরোধীদলীয় এমপিরা — Jugantor (matched: আগুন)
  https://www.jugantor.com/politics/1183782
- [a818] খুন করে আধা ঘণ্টা পর ঘটনাস্থলে এসে স্বীকার, অভিযুক্তকে পিটুনি দিয়ে পুলিশে সোপর্দ — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/bangladesh/district/2luzu9yef1
- [a822] টাকার জন্য জিম্মি, বাঁচাতে গেলে দুজনকেই চলন্ত বাস থেকে ফেলে হত্যা — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/video/bangladesh/q11sxofrqw
- [a823] টাকার জন্য জিম্মি, বাঁচাতে গেলে দুজনকেই চলন্ত বাস থেকে ফেলে হত্যা — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/video/bangladesh/1xdu46ukzo
- [a836] প্রতিবেদন দিতে আরও সাত কার্যদিবস সময় চেয়েছে স্বরাষ্ট্রের তদন্ত কমিটি — Prothom Alo Bangla (matched: আগুন)
  https://www.prothomalo.com/bangladesh/district/zz8vfy4zqg
- [a841] লালবাগ ও কামরাঙ্গীরচরে গভীর রাতে অভিযান, যুবলীগের দুই সদস্য গ্রেপ্তার: ডিএমপি — Prothom Alo Bangla (matched: গ্রেপ্তার)
  https://www.prothomalo.com/bangladesh/crime/xsudff745z
- [a844] দুজনকে চলন্ত বাস থেকে ফেলে হত্যা — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/bangladesh/district/dujnke-clnt-baas-theke-phele-htyaa
- [a845] দেশে মাসে ২৯৪ খুন, ১০ মাসে হত্যা মামলা ২ হাজার ৯৩৮টি — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/bangladesh/crime/8hzv8pyxoq
- [a860] বিয়ের চার মাসের মাথায় শ্বশুরবাড়ি থেকে নববধূর লাশ উদ্ধার, পরিবারের দাবি হত্যা — Prothom Alo Bangla (matched: হত্যা)
  https://www.prothomalo.com/bangladesh/district/orakpexgg3
- [a863] টুঙ্গিপাড়ায় বিএনপি ও যুবদলের কার্যালয়ে আগুন, ভাঙচুর — Prothom Alo Bangla (matched: আগুন)
  https://www.prothomalo.com/bangladesh/district/o6quxfkn3i
- [a880] Singer Shaikh Shahed Ali  no more — The Daily Star (matched: singer)
  https://www.thedailystar.net/news/bangladesh/obituary/news/singer-shaikh-shahed-ali-no-more-4323156
- [a897] 12 dead in Iran bus accident: state media — The Daily Star (matched: accident)
  https://www.thedailystar.net/news/world/news/12-dead-iran-bus-accident-state-media-4324316
