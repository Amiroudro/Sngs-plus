# Sarangsho Plus — v2 7-day correctness tracker

Target: **7 correct consecutive v2 editions** (CONTRACTS.md gate).
A v2 edition counts as correct only if it was published after
passing the full 15-check v2 gate with no failures.

The v1 run closed at **7/7 — TARGET REACHED** (Editions 9–15 Nov
2026, each 17/17, Edition 9 on 2026-11-15). The count reset to **0**
at the first v2 edition (Edition 11, 2026-11-17, Rudro's rule
2026-11-15, "other thing do yourself"): the first v2 edition is
v2 Day 1 and makes the v2 run 1/7. The v1 tracker
(`engine/runs/tracker.md`) is untouched by v2 publishes — v2 rows
go here, and `publish_v2.py --publish` sets
`correct_consecutive_editions` / `correct_rule` in both index.json
files (1 at the first v2 edition, +1 per later v2 edition).

| # | Date | Collected | Events | Kept | Borderline | Stories | Words | Phrases | MCQs | Review | Status | Notes |
|---|------|-----------|--------|------|------------|---------|-------|---------|------|--------|--------|-------|

**Correct consecutive editions so far: 0 / 7.**
