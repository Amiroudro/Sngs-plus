# Conversion report — v2 -> app, 2026-11-15

Staging only. Nothing published, synced or switched live.

## Editorial decision

- **14 news + 1 editorial = 15 stories**
- Why: validate_editions.py only requires counts == index, so 16 would pass it -- but publish.py's checklist caps stories at 15 (12-15 ok) and requires an Editorial & Opinion story, and v1 Edition 9 has exactly this shape (15 stories incl. 1 editorial). Dropping a news story keeps every gate green.
- Dropped news item: a317 — “Japan-led probe finds 1,000 servers suspected of supporting AI-driven cyberattacks” (lowest-ranked page item (score desc, then newest first)).
- Editorial carried as CA15: “From Kalabogi to COP31: The case for developed-nation responsibility” (Prothom Alo English).

## MCQ selection

- Letters: {'A': 6, 'B': 6, 'C': 6, 'D': 7} (target A6/B6/C6/D7, seeded shuffle).
- Longest-correct: 4/25 (MCQs [12, 13, 20, 24]).
- Current Affairs: 13 selected, 10 dropped by the filters.
- Dropped CA MCQs:
  - a385-mcq2 (a385): source quote not in this story's facts
  - a385-mcq3 (a385): source quote not in this story's facts
  - a378-mcq2 (a378): duplicate options in story
  - a369-mcq1 (a369): source quote not in this story's facts
  - a369-mcq2 (a369): stem matches another article's headline (a364)
  - a838-mcq2 (a838): duplicate options in story
  - a838-mcq3 (a838): duplicate options in story
  - a334-mcq2 (a334): duplicate options in story
  - a326-mcq3 (a326): source quote not in this story's facts
  - a311-mcq2 (a311): duplicate options in story

## EN summary rendering — examples (rendered from facts_en quotes)

### CA01: ADP implementation hits record low of 6.53% in Jul-Oct

Summary: The information was revealed in a report published by the Implementation Monitoring and Evaluation Division (IMED) of the planning ministry today (15 November).

Exam facts: The implementation rate of the government's Annual Development Programme (ADP) stood at just 6.53% in the first four months (July-October) of the current fiscal year of 2026-27, the lowest ever recorded for the period. The pace of ADP implementation remained sluggish during these two fiscal years amid administrative instability following the fall of the Awami League government in August 2024 and t

### CA02: Bangladesh exports fruits worth $126.35 million in FY26: Commerce minister

Summary: Bangladesh exported fruits worth $126.35 million in the 2025-26 fiscal year, Commerce Minister Khandaker Abdul Muktadir told parliament today (15 November). As part of the National Export Training Programme and Annual Performance Agreement, the EPB organised a seminar in Chapainawabganj on 19 October.

Exam facts: Bangladesh exports fruits worth $126.35 million in FY26: Commerce minister He disclosed the figure in response to a question from Dinajpur-2 lawmaker Md Sadik Riaz during the question-and-answer session on the fifth day of the fourth session of parliament.

### CA03: Flawed industrial data inflated GDP growth numbers in FY15-FY19: Govt audit

Summary: The findings were presented at a seminar "Peer Review of Forensic Audit Report on GDP Estimates", at the Bangladesh Bureau of Statistics (BBS) conference room in Agargaon today (14 November). The report found that average real GDP growth stood at 6.27% during FY11 to FY14.

Exam facts: According to the report, manufacturing accounted for nearly 41% of the additional GDP growth recorded between FY2014-15 and FY2018-2019 compared with the preceding four years. During the period, manufacturing's share of national GDP increased from 15.16% to 18.25%. As a result, the cement industry was shown to have recorded growth of 61.6%, 51.7% and 45.9% in three consecutive years since 2015.

## Fields left empty

- **key_people (EN + BN, all stories)** — v2 carries no key_people anywhere (no Step 4/5/6 field, no items-file field). Left empty; neither validator requires it.
- **exam_qa / recall_cards for the editorial story (CA15)** — the v2 editorial slot has no questions and no numeric facts to blank; lists left empty (shape-only checks).
- **Synonyms / Antonyms / Word family / Collocations / IPA / Bangla phonetic on today's 20 words** — v2 Step 10 enriches only words that appeared in an earlier v1 edition; none of today's 20 words (or 10 phrases) ever appeared as a v1 headword (checked: 305 v1 headwords, 0 overlap). No honest source exists in the repo -- see 'unmeetable'.
- **EN why_it_matters (all stories)** — v2's why_important line is Bangla ([পটভূমি] ...), so there is no English why-line to carry. EN why is a templated frame around the first verified fact quote (no new facts). BN why uses the real Bangla line where it exists (score-3 items).
- **EN summary/detail/exam_facts for Bangla-article stories** — facts_en for Bangla articles is untranslated Bangla (render_facts_en did not translate the a784 article). The 15 Nov page's only Bangla-article story is a784, kept as CA07, so its EN summary/detail/exam_facts ARE Bangla text in the staged file. Validators pass (the BN overlay covers those EN fields, so they are not scanned as Bengali text), but an English-mode user sees Bangla for CA07. Its BN overlay is correct Bangla. The gap belongs in render_facts_en (Step 4), not the converter.

## Repairs made by the converter

- phrase 'climate change': empty Original example 2 filled from a body sentence (items file)
- phrase 'prime minister': empty Original example 2 filled from a body sentence (items file)
- phrase 'economic growth': empty Original example 2 filled from a body sentence (items file)
- phrase 'loss and damage': empty Original example 2 filled from a body sentence (items file)
- phrase 'interim government': empty Original example 2 filled from a body sentence (items file)
- phrase 'revenue collection': empty Original example 2 filled from a body sentence (items file)

## What the converter CANNOT meet honestly

- **check_data.py #7/#8: synonym pool >= 15/20, antonym pool >= 10/20, collocation field >= 15/20, synonym/antonym distractor pools >= 4** — Today's 20 v2 words carry no synonyms/antonyms/collocations (see empty_fields). The converter cannot invent them, and no synonym source exists in the repo (vocab bank has Bangla meaning + English definition only). check_data.py WILL fail on #7/#8 for this edition. Fix belongs in Step 10 (a synonym/antonym source) or in the bank -- not in the converter.
- **publish.py checklist #13 (every summary AND figures carry a digit) and #16 (exam_facts adds >= 5 new tokens) for the editorial story CA15** — The editorial slot is one summary sentence with no numbers and no further facts. Its figures fall back to the publication date (has a digit) but its summary cannot honestly carry a digit, and its exam_facts cannot add new facts beyond the one sentence. The two required validators do not have these checks.
- **BN key_fact labels in Bangla (15 Nov run only)** — No Bangla structured facts were persisted for 15 Nov (no items file). BN labels are sanitised English 'what' text. From the next run, run_v2.py persists items-<date>.json and the converter can use Bangla fact text.

## Self-checks

- PASS counts — {'stories': 15, 'words': 20, 'phrases': 10, 'mcqs': 25, 'revision_words': 5}
- PASS mcq letters 5-8 each — {'A': 6, 'B': 6, 'C': 6, 'D': 7}
- PASS no '[example]'
- PASS no 'rice, wheat,'
- PASS word examples contain headword — []
- PASS phrase examples contain complement — []
- FAIL BN summary numbers preserved — [('CA09', '১৪'), ('CA10', '৫৬০')]
- PASS BN overlay: no Bangla violations (python replica) — []
- PASS BN key_fact originals clean — []
- PASS story ids CA01..CA15
- PASS MCQ sources are story ids
- PASS no dup top-level source URLs
- PASS BN story ids == EN
- PASS BN MCQ numbers == EN 1..25
- PASS BN story fields non-empty — all stories carry headline/summary/why/exam_facts/figures
- PASS EN one_liners <= 20 words
- PASS key_facts 1-4 per story
- PASS EN summaries <= 90 words — []
- PASS every story has >=1 http source

## Per-story notes

- CA01: summary dropped 2 quote(s) whose numbers are absent from the BN summary: [("The implementation rate of the government's Annual Developme", ['27']), ('The pace of ADP implementation remained sluggish during thes', ['2024'])]
- CA03: summary dropped 1 quote(s) whose numbers are absent from the BN summary: [('According to the report, manufacturing accounted for nearly ', ['2019'])]
- CA04: summary dropped 3 quote(s) whose numbers are absent from the BN summary: [('During a late-night inspection at Golden Container Ltd off-d', ['14']), ('Under Utilisation Permission (UP) No 6/2026(A), issued on 17', ['74031900']), ('According to the customs release, preliminary investigations', ['29'])]
- CA07: summary dropped 1 quote(s) whose numbers are absent from the BN summary: [('Bangladeshi firms lead 26 markets in supply chain shifts, 91', ['91'])]
- CA09: summary uses quote 1 although its numbers are not all in the BN summary (check_data #4 risk); summary dropped 5 quote(s) whose numbers are absent from the BN summary: [('রিট আবেদনটি হাইকোর্টের অবকাশকালীন বেঞ্চে গত ১৪ অক্টোবর শুনান', ['১৪']), ('এর আগে শিক্ষা মন্ত্রণালয়ের মাধ্যমিক ও উচ্চশিক্ষা বিভাগ গত ১', ['১৬']), ('লটারি পদ্ধতি বাতিলসংক্রান্ত গত ১৬ মার্চের স্মারক নিয়ে মুভমে', ['১৬', '৭']), ('এর আগে করোনাভাইরাসের সংক্রমণের কারণে ২০২১ শিক্ষাবর্ষে সব শ্র', ['২০২১']), ('মাধ্যমিক ও উচ্চশিক্ষা বিভাগ গত ১৬ মার্চ এক স্মারকে লটারি পদ্', ['১৬'])]
- CA10: summary uses quote 1 although its numbers are not all in the BN summary (check_data #4 risk); summary dropped 5 quote(s) whose numbers are absent from the BN summary: [('এনভিডিয়ার ছয় শীর্ষ কর্তার সম্পদ কমেছে ৫৬০ কোটি ডলার, তিনজন', ['৫৬০']), ('ফোর্বসের ১৩ নভেম্বর প্রকাশিত হিসাব অনুযায়ী, গত ৬ অক্টোবর থে', ['১৩', '৬', '১৩', '৫', '৬', '৫৬০']), ('কোম্পানিটির আরেক পরিচালক ও ভেঞ্চার ক্যাপিটাল বিনিয়োগকারী মা', ['২', '২০০']), ('গত ১২ নভেম্বর এনভিডিয়ার পরিচালনা পর্ষদের চেয়ারম্যান হিসেবে', ['১২', '৫০০', '৫০']), ('এনভিডিয়ায় তাঁদের প্রত্যেকের শেয়ারমালিকানার মূল্য ৬০০ থেকে', ['৬০০', '৭০০'])]
- CA15: EDITORIAL: structured fields are mechanically derived from the slot's single summary sentence (headline/source/url/ summary is all v2 carries for the মতামত slot); no figures, no key people, no Q&A exist for it.

## Mapping table (v1 field <- v2 source)

- **edition_date** <- run date (page date)
- **edition_day** <- weekday derived from the date
- **coverage** <- v1 formula, copied: previous day 07:47 Dhaka -> date 07:47 Dhaka
- **counts** <- len() of each list; sources = deduped story sources
- **story.id** <- CA01..CA15 in at_a_glance (ranked) order; editorial last
- **story.headline** <- v2 page headline, verbatim
- **story.category** <- v2 topic_primary mapped to the 7 fixed v1 categories (ENV->Bangladesh, SCI->Technology, SPORT/PEOPLE->Bangladesh if headline names Bangladesh else World)
- **story.event_date / article_date** <- articles file 'published' parsed to ISO; fallback edition date
- **story.summary (EN)** <- first 2 facts_en QUOTES (verbatim article sentences) whose numbers survive into the BN summary; <=90 words
- **story.why_it_matters (EN)** <- templated frame around the first verified quote (v2 why line is Bangla, no English source)
- **story.exam_facts (EN)** <- remaining facts_en quotes (3rd-5th)
- **story.exam_relevance** <- fixed template per v2 topic (no facts)
- **story.key_people** <- EMPTY -- v2 has no key_people anywhere
- **story.figures (EN)** <- value+unit per fact, else first number in the quote; fallback publication date
- **story.sources** <- v2 page item sources (name+url), headline = story headline
- **story.one_liner (EN)** <- first fact quote truncated to 20 words
- **story.key_facts (EN)** <- facts_en: label = 'what' (<=12 words), value = value+unit or fact date or first number, original = verbatim quote
- **story.what_happened (EN)** <- one bullet per facts_en quote
- **story.exam_qa (EN)** <- filtered v2 Q&A for the story (HTML dropped, why-QA excluded, cap 5)
- **story.recall_cards (EN)** <- first 2 facts with values: value blanked in its quote
- **story.keywords** <- headline content words (len>=4, stopwords removed, max 5)
- **story.detail (EN)** <- all facts_en quotes joined
- **BN story.headline** <- v2 headline, bn_sanitised (digits/months/Tk) -- NOT translated
- **BN story.summary / exam_facts** <- v2 fact_lines joined
- **BN story.why_it_matters** <- score-3: real [পটভূমি] line minus marker; else 'মনে রাখার তথ্য: <first fact line>'
- **BN story.figures** <- bn_sanitised EN figures
- **BN story.key_facts** <- label/value = bn_sanitised EN key_fact; original = Bangla fact line
- **BN story.what_happened** <- v2 fact_lines
- **BN story.exam_qa** <- sanitised v2 Q&A incl. the Bangla why-QA
- **BN story.recall_cards** <- first 2 fact lines: first Bangla number blanked
- **BN story.detail** <- focus_paragraph (score-3) sanitised, else fact_lines joined
- **words / phrases / revision_words** <- verbatim from vocab-<date>.json (phrase ex2 repaired when empty -- see repairs)
- **mcqs 1-10 Vocabulary** <- generated from vocab: 'What does X mean?', correct = English definition, distractors = 3 other definitions (longer preferred)
- **mcqs 11-12 Phrases** <- generated from phrases: 'What does the phrase X mean?', correct = English explanation, distractors = 3 other explanations
- **mcqs 13-25 Current Affairs** <- v2 MCQs filtered + round-robin one per story (see mcq section)
- **mcq.explanation (EN)** <- CA: 'Correct answer: <key>. Source: <source quote, <=300 chars>'; vocab/phrase: definition + verbatim example
- **mcq BN overlay** <- CA: sanitised stem/options/why_wrong[key]; vocab/phrase: Bangla question + Bangla meanings as options
- **sources[]** <- one per story: S01.., publication, headline, article_date, URL
- **index entry** <- live index.json copied, entry appended (stories 15, sources 15, DRY RUN review text)
