# Pre-filter log — 2026-11-14

Deprioritised headlines: 4 (low priority only; nothing was deleted, Step 3 still decides each one).

- [a020] Man claiming to lead 'Non-Fugitive Awami League' released from police custody; alleges mob attack — The Business Standard (matched: fire)
  https://www.tbsnews.net/bangladesh/man-claiming-lead-non-fugitive-awami-league-released-police-custody-alleges-mob-attack
- [a030] Fugitive son arrested in Gopalganj over father's murder in Narail — Dhaka Tribune (matched: murder)
  https://www.dhakatribune.com/bangladesh/nation/424647/fugitive-son-arrested-in-gopalganj-over-father-s
- [a070] No possibility of fire at Nusrat’s house from short circuit: Rural electricity official — Prothom Alo English (matched: fire)
  https://en.prothomalo.com/bangladesh/local-news/yh64q83nl9
- [a083] Nusrat’s home fire: Heated exchanges in parliament over cause of blaze — Prothom Alo English (matched: fire)
  https://en.prothomalo.com/bangladesh/politics/brz9duk9fd
